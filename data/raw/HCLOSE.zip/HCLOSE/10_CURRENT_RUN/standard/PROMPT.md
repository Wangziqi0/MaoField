Fill exactly one local proof gap in the fixed existing mathematical proof supplied below. The engineering setup and every other part of this proof are already prepared. Your local goal is:

    |normalizedPair P i j - H0 p i j| ≤ rho

All local variables and assumptions appear in the surrounding proof. Two arms receive exactly the same template and exact prior result declarations. Do not reconstruct a project, search files, rewrite the theorem or solve other parts of the paper.

Return only the Lean tactic lines that replace MODEL_PROOF_HERE inside the local `have hclose ... := by`. Do not include Markdown fences, imports, theorems, namespaces, file operations or the outer `have` declaration. The host indents your lines, inserts them into the fixed template and compiles it automatically. No new axioms, sorry or admit are allowed.

If an additional organized-information note is supplied, use its established results and stated applicability as appropriate. The note is not itself an axiom. The deliverable remains your own final local derivation. Compiler errors, if a correction attempt is allowed, will be returned directly.


Exact unchanged target definition:
```lean
namespace NavierStokes.PrimaryCovarianceBounds
def checkpoint_bridge_goal : Prop :=
  ∀ {X : Type u_1} [TopologicalSpace X] {K : Set X}
    (hK : IsCompact K) (H0 : X → Mat2) (T0 : X → Vec2)
    (hH0 : ∀ i j, ContinuousOn (fun p => H0 p i j) K)
    (hT0 : ∀ i, ContinuousOn (fun p => T0 p i) K)
    (hcone : ∀ p ∈ K, SmoothCovariance.StrictCone (H0 p) (T0 p))
    (vr vt : TorusInverse.Plane) (hdet : vr.1 * vt.2 - vr.2 * vt.1 ≠ 0)
    {r0 h a A b B E D : ℝ} (hr0 : 0 < r0) (hh : 0 ≤ h)
    (ha : 0 < a) (hA : 0 < A) (hb : 0 < b) (hE : 0 ≤ E) (hD : 0 ≤ D),
    ∃ N : ℕ, 4 ≤ N ∧ ∃ detGap entryBound inverseLower : ℝ,
      0 < detGap ∧ 1 ≤ entryBound ∧ 0 < inverseLower ∧
      ∀ n : ℕ, N ≤ n → ∀ p ∈ K, ∀ P : Fin 2 → PartitionedCovariance.Pulse,
        (∀ j, PulseCovariance.PulseBounds (slotRadius r0 h n) a A b B (P j).ψ (P j).x) →
        (∀ j i v, v ∈ Icc 0 (ChartScales.slotLength r0 h n) →
          |(P j).t v i / (P j).x v - H0 p i j| ≤ E / ChartScales.slotLength r0 h n +
            D * |v - ChartScales.slotLength r0 h n / 2| / ChartScales.slotLength r0 h n) →
        ∀ zeta : ℝ, 0 ≤ zeta →
        ZeroOrderBounds (Real.sqrt (ChartScales.S n)) detGap entryBound inverseLower zeta
          (PartitionedCovariance.pairMatrix vr vt r0 (fun _ => ChartScales.timeCoefficient h n) P)
          (FlatCovariance.scaledTarget zeta (T0 p))
end NavierStokes.PrimaryCovarianceBounds
```


# Common mathematical inputs

Both arms receive these identical existing declarations from NavierStokes.PrimaryCovarianceBounds. Their actual proofs are already available in the retained imported source. The fixed surrounding proof supplies the other parameters and assumptions.

```lean
theorem slotRadius_sq {r0 : ℝ} (hr0 : 0 < r0) (h : ℝ) (n : ℕ) :
    slotRadius r0 h n ^ 2 = ChartScales.slotLength r0 h n
```

```lean
noncomputable def normalizedPair (P : Fin 2 → PartitionedCovariance.Pulse) : Mat2 :=
  fun i j => PulseCovariance.normalizedColumn (P j).ψ (P j).x (P j).t i
```

```lean
theorem normalizedPair_entry_error {r a A b B E D : ℝ}
    (P : Fin 2 → PartitionedCovariance.Pulse)
    (hP : ∀ j, PulseCovariance.PulseBounds r a A b B (P j).ψ (P j).x)
    (H0 : Mat2) (hE : 0 ≤ E) (hD : 0 ≤ D)
    (hratio : ∀ j i v, v ∈ Icc 0 (r ^ 2) →
      |(P j).t v i / (P j).x v - H0 i j| ≤
        E / r ^ 2 + D * |v - r ^ 2 / 2| / r ^ 2) (i j : Fin 2) :
    |normalizedPair P i j - H0 i j| ≤
      (E + D * PulseCovariance.concentrationConstant a A b B) / r
```

Fixed surrounding proof (only MODEL_PROOF_HERE is editable):
```lean
import Checkpoint.NodeGoal

noncomputable section
open Set
open NavierStokes NavierStokes.PrimaryCovarianceBounds

namespace Branch.Direct

theorem completed {X : Type*} [TopologicalSpace X] {K : Set X}
    (hK : IsCompact K) (H0 : X → Mat2) (T0 : X → Vec2)
    (hH0 : ∀ i j, ContinuousOn (fun p => H0 p i j) K)
    (hT0 : ∀ i, ContinuousOn (fun p => T0 p i) K)
    (hcone : ∀ p ∈ K, SmoothCovariance.StrictCone (H0 p) (T0 p))
    (vr vt : TorusInverse.Plane) (hdet : vr.1 * vt.2 - vr.2 * vt.1 ≠ 0)
    {r0 h a A b B E D : ℝ} (hr0 : 0 < r0) (hh : 0 ≤ h)
    (ha : 0 < a) (hA : 0 < A) (hb : 0 < b) (hE : 0 ≤ E) (hD : 0 ≤ D) :
    ∃ N : ℕ, 4 ≤ N ∧ ∃ detGap entryBound inverseLower : ℝ,
      0 < detGap ∧ 1 ≤ entryBound ∧ 0 < inverseLower ∧
      ∀ n : ℕ, N ≤ n → ∀ p ∈ K, ∀ P : Fin 2 → PartitionedCovariance.Pulse,
        (∀ j, PulseCovariance.PulseBounds (slotRadius r0 h n) a A b B (P j).ψ (P j).x) →
        (∀ j i v, v ∈ Icc 0 (ChartScales.slotLength r0 h n) →
          |(P j).t v i / (P j).x v - H0 p i j| ≤ E / ChartScales.slotLength r0 h n +
            D * |v - ChartScales.slotLength r0 h n / 2| / ChartScales.slotLength r0 h n) →
        ∀ zeta : ℝ, 0 ≤ zeta →
        ZeroOrderBounds (Real.sqrt (ChartScales.S n)) detGap entryBound inverseLower zeta
          (PartitionedCovariance.pairMatrix vr vt r0 (fun _ => ChartScales.timeCoefficient h n) P)
          (FlatCovariance.scaledTarget zeta (T0 p)) := by
  obtain ⟨rho, delta, M, hrho, hdelta, hM, hmargin⟩ := compact_model_margins hK H0 T0 hH0 hT0 hcone
  let kappa := PartitionedCovariance.nativePrefactor vr vt r0
  have hkappa : 0 < kappa := PartitionedCovariance.nativePrefactor_pos hdet hr0
  let lo := scalarLower kappa r0 a B
  let hi := scalarUpper kappa r0 A b
  have hlo : 0 < lo := scalarLower_pos hkappa hr0 ha
  have hhi : 0 < hi := scalarUpper_pos hkappa hr0 hA hb
  let Q := E + D * |PulseCovariance.concentrationConstant a A b B|
  have hQ : 0 ≤ Q := by dsimp [Q]; positivity
  obtain ⟨N, hN4, hN⟩ := eventually_slotRadius_large hr0 hh (max 1 (Q / rho))
  refine ⟨N, hN4, lo ^ 2 * delta, max 1 (hi * M), delta / hi,
    by positivity, le_max_left _ _, div_pos hdelta hhi, ?_⟩
  intro n hn p hp P hP hratio zeta hzeta
  have hn4 : 4 ≤ n := hN4.trans hn
  have hr : 0 < slotRadius r0 h n := slotRadius_pos hr0 h n
  have hrlarge : Q / rho ≤ slotRadius r0 h n := (le_max_right _ _).trans (hN n hn)
  have hsmall : Q / slotRadius r0 h n ≤ rho := by
    apply (div_le_iff₀ hr).mpr
    have ht := (div_le_iff₀ hrho).mp hrlarge
    nlinarith
  have hclose (i j : Fin 2) : |normalizedPair P i j - H0 p i j| ≤ rho := by
    -- MODEL_PROOF_HERE
  obtain ⟨hd, hw, he⟩ := hmargin p hp (normalizedPair P) hclose
  have hscale (j : Fin 2) : lo ≤ Real.sqrt (ChartScales.S n) *
      pairScales kappa (fun _ => ChartScales.timeCoefficient h n) P j ∧
      Real.sqrt (ChartScales.S n) * pairScales kappa (fun _ => ChartScales.timeCoefficient h n) P j ≤ hi :=
    chart_column_mass_bounds hr0 hh hkappa hn4 (hP j)
  have hR : 0 < Real.sqrt (ChartScales.S n) := Real.sqrt_pos.mpr (ChartScales.S_pos (by omega))
  have hbounds := column_scale_bounds (normalizedPair P) (T0 p)
    (pairScales kappa (fun _ => ChartScales.timeCoefficient h n) P)
    hR hlo hhi hdelta hzeta hscale hd hw he
  rw [pairMatrix_factorization P hP vr vt r0]
  exact ⟨hbounds.1, fun i j => (hbounds.2.1 i j).trans (le_max_right _ _), hbounds.2.2⟩

end Branch.Direct

#check (Branch.Direct.completed : NavierStokes.PrimaryCovarianceBounds.checkpoint_bridge_goal)
#print axioms Branch.Direct.completed

```
