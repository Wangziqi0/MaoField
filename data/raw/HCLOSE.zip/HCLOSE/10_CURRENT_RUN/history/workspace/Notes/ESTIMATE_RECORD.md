# Recorded upstream estimates and their scope

This record extracts statements already present in the retained source. It is an adoption record, not a fabricated search history. No unsuccessful mathematical attempt is asserted here.

For a pulse satisfying `PulseBounds r a A b B`, the retained proofs bound the actual positive mass below by `lowerMassConstant a B * r` and above by `A^2 * sqrt(pi / (2*b)) * r`. The centered-moment estimate is for the same actual cutoff and solution components; the normalized direction estimate is derived from these integrals.

`PrimaryCovarianceBounds.normalizedPair_entry_error` applies to the actual `PartitionedCovariance.Pulse` objects. Its pointwise premise has the two terms `E/r^2` and `D*abs(v-r^2/2)/r^2`; its integrated conclusion bounds each normalized matrix entry error by `(E + D*concentrationConstant a A b B)/r`. Its nonnegativity, interval and continuity premises are part of the source statement.

`compact_model_margins` concerns a compact family of model matrices and targets already in the strict cone. It supplies a uniform entrywise perturbation tolerance, positive determinant/weight margins and an entry bound for matrices within that tolerance. It does not itself establish that any selected actual covariance lies within it.

`chart_column_mass_bounds` concerns the actual native scalar mass factors, and `eventually_slotRadius_large` concerns the actual chart radius. The full definitions and all quantifier order are retained in the source rather than replaced by order notation.

`ZeroOrderBounds` keeps `inverseLower * R * zeta` in the inverse-weight lower bound. Positivity of a weight requires a positive flat target factor; it is not asserted at a zero of that factor. The existing weighted derivative tools and zero-extension lemmas must be applied with their actual hypotheses.

`PrimaryTargetBounds.primary_center_error` supplies the pointwise error for the retained selected phase/ODE family, and `familyCovariance_eq_native` identifies its covariance with the native object. The two uniform assembly statements in `Checkpoint/OPEN_OBLIGATION.md` are still open. Completing one assembly component is not completion of the entire primary stress construction or the full Navier–Stokes endpoints.
