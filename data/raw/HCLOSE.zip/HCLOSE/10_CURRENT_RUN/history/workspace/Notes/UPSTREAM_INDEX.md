# Existing upstream work at the reconstructed checkpoint

Identity: source-open adoption and local reconstruction from the pinned public source, not the original author's discovery history. All files listed here are available to both continuation policies. Source comments that retrospectively describe later uses were removed; the mathematical statements and retained proofs are present. The actual local validation receipt belongs to the visible history.

| Existing product | Main source files | What it establishes |
|---|---|---|
| Constructed slow base and selected representatives | `FinalSlowBase.lean`, `PrimaryGeometryAssembly.lean`, `BaseChartJets.lean` | The same slow base, positive support cells, representatives, target direction and selected phase data used by this reconstruction. |
| Actual phase and ODE estimates | `BasePhaseGeometry.lean`, `PrimaryPulseBounds.lean`, `PrimaryTargetBounds.lean` | The actual normalized homogeneous solution, coefficient control, phase geometry and pointwise center errors. The target file currently ends at `familyCovariance_eq_native`. |
| Actual pulse integrals | `PulseCovariance.lean` | Positive Gaussian mass, upper mass and centered-moment bounds, normalized-column errors and conditional column rescaling. |
| Compact model geometry | `SmoothCovariance.lean`, `PrimaryCovarianceBounds.lean` | Strict-cone perturbation margins and conditional finite-matrix estimates. |
| Native scales | `ChartScales.lean`, `PrimaryCovarianceBounds.lean` | Positive column scale bounds and growth of the actual slot radius with the band. |
| Conditional actual covariance identities | `PartitionedCovariance.lean` | Actual angular/torus averages, separated wave supports and partition identities. Their hypotheses still need to be satisfied by the completed construction. |
| Derivatives and edges | `WeightedClasses.lean`, `WeightedQuotients.lean`, `WeightedPositiveRoot.lean`, `FlatCovariance.lean` | General weighted derivative, square-root, quotient and smooth zero-extension tools. These are not an actual primary or signed-wave solution. |

Paths in this table are under `NavierStokes/`. `Checkpoint/OPEN_OBLIGATION.md` contains the two open assembly signatures. The exact full targets are in the public `GoalSpec.lean` and its statement-only dependencies.

The existing results may be used directly, organized into a compact sufficient interface, or legitimately rederived. No particular amount of historical reading is required. The first bridge, the whole primary realization, the signed correction and the complete main/periodic goals have distinct completion meanings.
