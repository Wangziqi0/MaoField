# 给 Pro 的实验结果、过程和叙事裁决包

本包由 PI 于 2026-09-20 明确要求制作。它是只读审阅交接，不是新实验、发表或自动下一轮的授权。

**已观察结果：一个已知公开证明中的同一局部缺口，一次配对、同模型、相同每臂三次请求上限。HISTORY 在第三次提交通过 Lean；STANDARD 在三次请求内未完成。** 这是一条有限、探索后的局部结果，不是完整 NS 新证明、完整历史优越性、普遍模型能力结论或因果机制已经被单独识别。

## 建议阅读顺序

1. `01_PROMPT_TO_PRO.md`：PI希望你完成的叙事连接和科学裁决。
2. `02_RESULT_AND_CLAIM_BOUNDARY.md` 与 `04_PROCESS_TIMELINE.md`：实际结果及失败。
3. `03_PARAMETERS.md`：模型、随机种子、预算、工具链、接受规则。
4. `20_TASK_AND_RUNNER/`：共同模板、两个原始提示、额外整理及执行代码；两组实际首请求在 `10_CURRENT_RUN/*/requests/0000/request.json`。
5. `05_DESIGN_EVOLUTION_AND_SELECTION.md` 与 `06_NARRATIVE_MAP_FOR_DECISION.md`：说明为什么改成这一缺口，以及现有证据与母问题之间还缺什么。
6. 需要逐项复核时，直接查看 `10_CURRENT_RUN/` 的原始请求、响应、全部候选、编译输出和 receipts。

## 一眼结果

| 组别 | 最终状态 | 请求数 | 输入 tokens | 输出 tokens |
|---|---|---:|---:|---:|
| HISTORY | EXACT_LOCAL_GOAL_LEAN_ACCEPTED | 3 | 25,757 | 20,781 |
| STANDARD | NOT_COMPLETED_WITHIN_THREE_REQUESTS | 3 | 12,124 | 41,009 |

共 6 次模型生成，37,881 输入 tokens、61,790 输出 tokens；未知请求 0；本轮新整理模型调用 0。输出计量包括服务器返回的 reasoning/completion 消耗，不能只当作可见代码长度。

## 包中有什么

- `10_CURRENT_RUN/`：本轮完整持久记录，两个终态工作区、六次完整请求、原始 SSE、可见输出、模型返回的 reasoning 字段、五次真实编译及截断返回。
- `20_TASK_AND_RUNNER/`、`21_SHARED_EXECUTION_CODE/`、`22_ENVIRONMENT/`：实际运行代码、环境回执、版本与参数。没有重新跑科学检查。
- `23_REVIEW_ONLY_ORIGINAL_SOURCE/`：仅供你审阅的完整原源及公开文稿文本，**不是受试模型的附加输入**。
- `30_PRIOR_DESIGNS/`：原 Pro 方案和 PI 理论驱动定位原文；其中旧执行要求是历史对象，不能当成这次会话的新授权。
- `31_EARLIER_RUNS/`：前序失败、停止、材料准备问题的原有报告及分支终态，避免只看最后正结果。
- `32_INDEPENDENT_DIAGNOSTIC/`、`33_RESEARCHER_RECHECK/`：目标选择前的能力诊断/研究者复算，不并入正式配对。
- `40_PI_STEERING/`：本次关键 PI 指令的会话摘录，附摘录身份说明。
- `PACKAGE_MANIFEST.json`：文件字节及 SHA-256；`SOURCE_MANIFEST.json`：来源定位。

`wire.bin` 是原始文本流；`.utf8` 可直接作为 UTF-8 文本读。模型生成的 reasoning 是过程数据，不是事实、认知机制测量或可信解释。

本包不含模型权重、Docker 镜像、已编译库缓存、SSH 私钥或 Codex 私有会话/内部推理。详见 `07_REPRODUCIBILITY_AND_CONTENTS.md`。
