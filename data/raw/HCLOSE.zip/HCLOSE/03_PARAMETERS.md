# 详细参数（以原请求和绑定回执为准）

| 项目 | 实际设置 |
|---|---|
| 模型服务名 | qwen3.8-27b-fp8-a256k-nomtp-c1 |
| 模型路径记录 | /home/amd/models/Qwen3.8-27B-FP8 |
| 参数来源 | 运行回执/启动argv；本包不重新验证模型权重品牌或训练数据 |
| temperature / top_p / top_k | 1.0 / 0.95 / 20 |
| presence_penalty / repetition_penalty | 0 / 1 |
| reasoning_effort | medium |
| ignore_eos | false |
| 上下文长度 | 262,144 tokens |
| 每次最大输入 / 输出 | 196,608 / 32,768 tokens |
| 输出上限是否含reasoning | 是，见标准组首次耗尽上限的receipt |
| 种子 | 1775273732；同一attempt两组相同，后两次各+1 |
| 实际执行顺序 | HISTORY → STANDARD；prepare随机洗牌一次，实际顺序写入PLAN |
| 样本规模 | 1 paired seed × 2 arms |
| 每组预算 | 1次初始请求 + 最多2次失败反馈修订，共≤3 |
| 模型工具 | 无；只返回纯Lean tactic body |
| 编译反馈 | stdout/stderr分别末12,000字符，原始全流保存；每项显式截断标记 |
| 新整理模型调用 | 0；本轮材料为研究者整理，非盲代理生成 |
| 有效目标 | 固定`hclose`缺口；外围定理类型保持不变 |
| 禁止占位 | 文本拒绝sorry/admit/axiom/sorryAx；最终依赖须为允许集合 |
| 接受条件 | BUILD_COMPLETED + 原精确外围目标类型检查 + 允许公理打印读回 |
| 每组首次prompt tokens | HISTORY 2,873；STANDARD 2,541；差332 |
| 独立内核认证 | 本轮未执行 |

服务器记录：dtype=half，quantization=fp8，tensor parallel=2，pipeline parallel=1，KV cache=turboquant_k8v4，max-num-seqs=1，max-num-batched-tokens=2560，prefix caching开启，GPU memory utilization=0.96，MTP未配置。记录的两张GPU各为NVIDIA GeForce RTX2080Ti、22,528MiB。硬件/模型身份来自原始观测回执，不另做性能因果归因。

Lean工具链为4.34.0-rc2；mathlib和Comparator锁定在工作区lake-manifest及lakefile中。隔离镜像ID为sha256:d88d6aeca21fb72f395a49b102a2a4e72e94811a81f4e35ab22d94fe7a9d8af8。原公开源码commit为f9e8bc5b38b6e212696e8a30e3e91517af887bbd。

精确配置：`10_CURRENT_RUN/PLAN.json`、每次`requests/NNNN/request.json`、`22_ENVIRONMENT/FORMAL_RUNTIME_ACCEPTED.json`、各组`BUILD_STATE.json`。机器可读汇总：`08_DERIVED_TABLES/EXACT_PARAMETERS.json`。

模型服务和编译环境预先存在；本轮未重启模型，也未另做新工程/整理模型请求。共同上游编译缓存为原cut加空入口构建，各组增量缓存独立。编译后的chmod报Operation not permitted属于保留的非致命反馈噪声；其末尾也实际进入修订提示，不能在分析时假定反馈完全干净。
