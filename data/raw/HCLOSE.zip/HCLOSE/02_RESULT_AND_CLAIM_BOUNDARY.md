# 实际结果及主张边界

## 已发生的事实

实验对象是局部命题 `|normalizedPair P i j - H0 p i j| ≤ rho`。它位于原公开 `compact_chart_pair_bounds` 证明中；外围固定，受试模型只能输出 `hclose` 的 tactic body。插入后检查的是整个外围定理与原 `checkpoint_bridge_goal` 的精确类型，并读取其公理依赖。

HISTORY三次全部产生候选：前两次失败，第三次成功。最后记录为 `EXACT_LOCAL_GOAL_LEAN_ACCEPTED`，允许公理列表为 `propext, Classical.choice, Quot.sound`，无 `sorryAx`。成功路径：`10_CURRENT_RUN/history/submissions/20260920T114931908693/RESULT.json`、同目录 `candidate.lean` 和 `compile/stdout.bin`。

STANDARD三次：第一次 `finish_reason=length`，32,768 completion tokens、可见输出空，记录 `PROOF_BODY_TRUNCATED`，没有编译该空体；后两次候选未通过。最后状态为 `NOT_COMPLETED_WITHIN_THREE_REQUESTS`，不是数学反例，也不是模型永远无法完成。最后路径：`10_CURRENT_RUN/standard/submissions/20260920T121411892800/`。

标准最后候选已使用 `normalizedPair_entry_error` 和 `slotRadius_sq`。它转换了区间成员条件，却直接以含slotLength的 `hratio` 结论去满足含slotRadius平方的目标，缺少对结论表达式的相应重写。不能写成标准组未找出关键引理。

## 可支持的最窄陈述

在这一个经过探索后选定的已知证明补全任务、一个配对种子和每组最多三次请求的预算下，附加具体适用说明的条件完成了经Lean检查的局部接续；只有相同外围证明和原有引理声明的条件没有在该预算内完成。

成功代码实际使用了整理说明指出的结果和变换。这是可定位的使用痕迹；不是对模型内部认知过程的直接观测，也不能单独证明唯一因果路径。

## 不能由本轮推出

- 未获得完整NS或周期终点的新证明；外围已知证明由宿主固定提供。
- 未复演原作者的独立发现、全部协作过程或突破时刻。
- 未检验完整历史相对于压缩历史的普遍优越性，也未检验不可压缩性。
- 未把长度、具体解题提示、排列与组织方式分离；HISTORY只是程序组名。
- 单缺口、单配对、探索后选题，不给统计稳定性、跨问题或跨模型泛化结论。
- 相同请求上限不是相同实际计算消耗，两组输入、输出、截断与反馈轨迹不同。
- Lean构建和打印依赖是本轮的实际检查范围；未对本轮候选额外运行独立内核认证。

## 叙事上值得讨论的真实连接

成功的 `hclose` 在固定外围证明中被 `hmargin` 实际接受，随后与 `column_scale_bounds` 等已有结果构成 `ZeroOrderBounds`。因此，局部形成物确实有一个经过类型检查的下游使用关系。但下游组织已预先写好；不能将其扩大为模型自主构建整个后继研究过程或循环再生产。
