# 六次实际请求与处理轨迹

时间在原记录中为UTC；北京时间加8小时。首请求2026-09-20 03:36:39.894748UTC，整轮结束04:14:49.157536UTC。约38分09秒包含模型生成、编译、缓存及调度，不等同纯推理时间。

| 组别 | 第几次 | finish_reason | 输入tokens | 输出tokens | 提交结果 |
|---|---:|---|---:|---:|---|
| HISTORY | 1 | stop | 2,873 | 6,230 | CANDIDATE_NOT_COMPILED |
| HISTORY | 2 | stop | 8,805 | 6,225 | CANDIDATE_NOT_COMPILED |
| HISTORY | 3 | stop | 14,079 | 8,326 | EXACT_LOCAL_GOAL_LEAN_ACCEPTED |
| STANDARD | 1 | length | 2,541 | 32,768 | PROOF_BODY_TRUNCATED |
| STANDARD | 2 | stop | 2,607 | 3,181 | CANDIDATE_NOT_COMPILED |
| STANDARD | 3 | stop | 6,976 | 5,060 | CANDIDATE_NOT_COMPILED |

HISTORY第一次出现缩进/语法问题并留下未完成目标；第二次仍未通过；第三次最终构造了完整的区间改写、积分误差界、分子比较和传递步骤。全部候选和编译反馈保留，没有只保留最后成功版。

STANDARD第一次达到32,768输出token上限但visible.utf8为空，因此宿主没有编译，直接反馈要求完整证明体。第二、第三次实际编译；最后仍有`hratio`结论形式与需要的平方半径形式不匹配。这是预算内形式化未完成，不是一个否定数学命题的证据。

原始一手轨迹：每组`requests/0000..0002/`中的request.json、receipt.json、wire.bin、visible.utf8、reasoning.utf8、COMPILER_FEEDBACK.json。五次编译各自位于submissions。最终证明文件为各组workspace/Branch/Direct.lean；中间版本在submissions保留。

`08_DERIVED_TABLES/ATTEMPTS.csv`逐次列出时间、用量、种子、返回原因、候选状态、编译耗时与证据路径。derived表只是便于阅读，原始receipts是计量来源。
