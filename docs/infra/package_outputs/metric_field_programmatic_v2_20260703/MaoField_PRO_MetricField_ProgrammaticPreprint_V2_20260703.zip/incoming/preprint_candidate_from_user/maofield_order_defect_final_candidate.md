#### Claim boundary.

The established contribution in this note is the finite-dimensional
theorem and its exact rational witness. The MaoField sections are a
research programme and set of proposed objects for later work. They do
not assert a new broad ANOVA theory, a new dependent-input decomposition
theory, a new theory of noncommuting projections, or an empirical
finding about language models.

# Introduction

Modern language-model evaluation is no longer a single accuracy
computation on a fixed test set. Large benchmark suites such as
BIG-bench and HELM deliberately combine heterogeneous tasks, scenarios
and metrics; trustworthiness and safety evaluations add dimensions such
as robustness, bias, privacy, toxicity and ethics; open-ended chat
evaluation often uses human or model judges rather than transparent
reference matching . These developments are necessary, but they also
make evaluation scores composite objects. A scalar score may depend on
at least six coupled choices: the prompt distribution, benchmark axes,
judge or grader, rubric, sampling policy, and aggregation weights.

The present note studies a deliberately small object: a finite positive
weighted two-way table. The table can be read abstractly as a
mathematical object, or prospectively as a toy model for an evaluation
grid whose rows are query classes and whose columns are benchmark
conditions, judges, rubrics or behavioural contexts. The mathematical
question is whether one may remove row-main effects and column-main
effects in either order without changing the resulting residual. The
answer is exact: order independence holds if and only if the table
weights factor as a product of row and column marginals.

The point is not that this two-axis theorem explains language models. It
does not. The point is that a non-product sampling or aggregation design
can make a sequential residual depend on procedural order. In such a
case, a non-zero residual-like quantity can be a measurement artifact
rather than evidence of a true interaction term. That distinction is
central to any future residual-metric audit of black-box model
evaluations.

#### Contributions.

The paper makes three bounded contributions:

1.  It proves a finite theorem: in $L^2(w)$ on $Q\times B$, centred row
    and column main-effect spaces are orthogonal exactly when
    $w(q,b)=w_Q(q)w_B(b)$ for every cell.

2.  It proves that two sequential main-effect stripping maps commute
    exactly under the same product-weight condition.

3.  It gives an exact non-product $2\times2$ rational witness in which a
    pure main-effect signal has zero true additive residual but non-zero
    wrong-order sequential output.

The final sections state a MaoField research programme: use finite
residual charts, weight audits and order-defect tests to separate model
behaviour from metric artefacts in complex black-box evaluations. This
is a proposed direction, not a result of the present note.

# Finite weighted setup

Let $Q$ and $B$ be finite non-empty sets and let $X=Q\times B$. Let
$w:X\to(0,1]$ be strictly positive and normalized:
$$\sum_{q\in Q}\sum_{b\in B} w(q,b)=1.$$ Work in
$H=\mathbb{R}^{Q\times B}$ with weighted inner product
$$\langle f,g\rangle_w=\sum_{q,b} w(q,b)f(q,b)g(q,b).$$ The row and
column marginals are
$$w_Q(q)=\sum_b w(q,b),\qquad w_B(b)=\sum_q w(q,b).$$ Define
$$C=\operatorname{span}\{\mathbf{1}\},$$
$$A=\left\{f(q,b)=a(q):\sum_q w_Q(q)a(q)=0\right\},$$
$$B_0=\left\{f(q,b)=c(b):\sum_b w_B(b)c(b)=0\right\}.$$ Let
$$N_{\rm add}=C\oplus A\oplus B_0$$ as an algebraic direct sum. The
symbol $\oplus$ here is not an orthogonal direct sum unless
$A\perp B_0$. Let $P_C$, $P_A$, $P_{B_0}$ and $P_{N_{\rm add}}$ denote
the weighted orthogonal projections onto $C$, $A$, $B_0$ and
$N_{\rm add}$ respectively.

The ordered stripping operators are
$$R_{Q\to B}=(I-P_{B_0})(I-P_A)(I-P_C),$$
$$R_{B\to Q}=(I-P_A)(I-P_{B_0})(I-P_C),$$ and the order-defect operator
is $$D_w=R_{Q\to B}-R_{B\to Q}.$$

<div class="lemma">

**Lemma 1** (Elementary intersections). *$C\perp A$, $C\perp B_0$, and
$A\cap B_0=\{0\}$.*

</div>

<div class="proof">

*Proof.* For $a\in A$,
$\langle \mathbf{1},a\rangle_w=\sum_q w_Q(q)a(q)=0$, and similarly for
$B_0$. If a function lies in both $A$ and $B_0$, then $a(q)=c(b)$ for
all $(q,b)$, hence the function is constant on $Q\times B$. Its marginal
mean is zero, so the constant is zero. ◻

</div>

# Order-independence theorem

<div class="theorem">

**Theorem 1** (Product weights, orthogonality and order independence).
*For finite positive weights on $Q\times B$, the following are
equivalent:*

1.  *$w(q,b)=w_Q(q)w_B(b)$ for every $q\in Q$ and $b\in B$;*

2.  *$A\perp B_0$ in $L^2(w)$;*

3.  *$D_w=0$;*

4.  *$R_{Q\to B}=R_{B\to Q}$.*

*When these conditions hold,
$$R_{Q\to B}=R_{B\to Q}=I-P_{N_{\rm add}}.$$ If they fail, then there
exists a pure main-effect witness $K\in A$ or $K\in B_0$ such that
$$(I-P_{N_{\rm add}})K=0,$$ one ordered stripping output is zero, and
the other ordered stripping output is non-zero.*

</div>

<div class="proof">

*Proof.* First suppose $w(q,b)=w_Q(q)w_B(b)$. For $a\in A$ and
$c\in B_0$, $$\langle a,c\rangle_w=\sum_{q,b}w_Q(q)w_B(b)a(q)c(b)
=\left(\sum_q w_Q(q)a(q)\right)
\left(\sum_b w_B(b)c(b)\right)=0.$$ Thus $A\perp B_0$.

Conversely assume $A\perp B_0$. For fixed $q_0,b_0$, define centred
indicators $$a_{q_0}(q)=\mathbf{1}_{q=q_0}-w_Q(q_0),\qquad
c_{b_0}(b)=\mathbf{1}_{b=b_0}-w_B(b_0).$$ They lie in $A$ and $B_0$.
Their inner product is $$\langle a_{q_0},c_{b_0}\rangle_w
=w(q_0,b_0)-w_Q(q_0)w_B(b_0).$$ Orthogonality therefore gives the
product identity cell by cell. This proves $(i)\Leftrightarrow(ii)$.

Next note that $P_A\mathbf{1}=P_{B_0}\mathbf{1}=0$, so
$$D_w=(I-P_{B_0})(I-P_A)(I-P_C)-(I-P_A)(I-P_{B_0})(I-P_C)
=P_{B_0}P_A-P_AP_{B_0}.$$ If $A\perp B_0$, then
$P_AP_{B_0}=P_{B_0}P_A=0$, and $D_w=0$.

Conversely suppose $D_w=0$. For any $b\in B_0$,
$$0=D_wb=P_{B_0}P_Ab-P_Ab.$$ Thus $P_Ab\in A$ and
$P_Ab=P_{B_0}P_Ab\in B_0$. By the lemma, $P_Ab=0$. Since $P_A$ is the
orthogonal projection onto $A$, this says every $b\in B_0$ is orthogonal
to $A$, hence $A\perp B_0$. This proves $(ii)\Leftrightarrow(iii)$, and
$(iii)\Leftrightarrow(iv)$ follows from the definition of $D_w$.

When $A\perp B_0$, the three subspaces $C,A,B_0$ are mutually orthogonal
and $P_{N_{\rm add}}=P_C+P_A+P_{B_0}$. The ordered products therefore
reduce to $I-P_{N_{\rm add}}$.

It remains to prove the existential witness under non-product weights.
If the weights are non-product, $A$ and $B_0$ are not orthogonal. Hence
there is some $K\in B_0$ with $P_AK\ne0$; otherwise all of $B_0$ would
be orthogonal to $A$. Since $K\in B_0$, $P_CK=0$ and $P_{B_0}K=K$.
Therefore $$R_{B\to Q}K=(I-P_A)(I-P_{B_0})(I-P_C)K=0.$$ On the other
hand, $$R_{Q\to B}K=(I-P_{B_0})(I-P_A)K=-(I-P_{B_0})P_AK.$$ If this
vector were zero, then $P_AK=P_{B_0}P_AK$ would lie in
$A\cap B_0=\{0\}$, contradicting $P_AK\ne0$. Thus $R_{Q\to B}K\ne0$.
Finally $K\in N_{\rm add}$, so $(I-P_{N_{\rm add}})K=0$. The non-zero
wrong-order output is therefore not a true additive residual. ◻

</div>

# Exact $2\times2$ rational certificate

Let $$w=\frac1{11}\begin{pmatrix}1&2\\3&5\end{pmatrix},$$ with cells
ordered as $((q_1,b_1),(q_1,b_2),(q_2,b_1),(q_2,b_2))$. The marginals
are $$w_Q=\left(\frac3{11},\frac8{11}\right),\qquad
w_B=\left(\frac4{11},\frac7{11}\right).$$ The weight is not product
form, since $w(q_1,b_1)=1/11$ while $w_Q(q_1)w_B(b_1)=12/121$.

Consider the pure column-main-effect witness
$$K=\left(\frac7{11},-\frac4{11},\frac7{11},-\frac4{11}\right)\in B_0.$$
It has zero $w$-mean and belongs to $N_{\rm add}$, hence
$$(I-P_{N_{\rm add}})K=0.$$ The column-first order removes it
immediately: $$R_{B\to Q}K=0.$$ The row-first order gives the exact
non-zero vector $$R_{Q\to B}K=
\left(\frac1{32},\frac5{168},-\frac1{96},-\frac1{84}\right).$$
Consequently $$\|R_{Q\to B}K\|_w^2
=\frac1{11}\left(\frac1{32}\right)^2
+\frac2{11}\left(\frac5{168}\right)^2
+\frac3{11}\left(\frac1{96}\right)^2
+\frac5{11}\left(\frac1{84}\right)^2
=\frac{61}{177408}.$$ This example is intentionally minimal. It is not a
numerical experiment; it is an exact rational certificate.

# Why this matters for residual metrics

A residual is often interpreted as what remains after nuisance structure
has been removed. The theorem shows that this interpretation is unsafe
unless the residual is tied to the correct projection. In the present
finite object there are two very different quantities:
$$\text{true additive residual: }(I-P_{N_{\rm add}})K,$$
$$\text{sequential stripping output: }R_{Q\to B}K\text{ or }R_{B\to Q}K.$$
Under product weights these coincide. Under non-product weights they
need not. The exact witness has a true additive residual equal to zero
and a non-zero wrong-order output. Therefore the wrong-order output is
an artifact of the stripping procedure, not evidence of a true
interaction term.

This is the whole mathematical warning. It is small, exact and finite.
Its value lies in making one class of metric artefact explicit before it
is hidden inside larger evaluation pipelines.

# MaoField programme: residual audits of complex black-box metrics

This section is programmatic. It proposes research objects that could be
developed later; it does not assert that they have already been
empirically observed.

## Metrics as composite operators

For language models, an evaluation score is rarely a primitive
observable. It is produced by a composite operator:
$$\text{score}=\mathcal{M}(\text{model},\text{prompts},\text{judge},\text{rubric},\text{sampling},\text{weights},\text{post-processing}).$$
The opacity of this operator is not only the opacity of the model. It is
also the opacity of the measurement apparatus. HELM explicitly argues
for multi-metric evaluation; BIG-bench aggregates a heterogeneous set of
tasks; LLM-as-judge methods introduce another learned model into the
measurement loop; contamination studies show that benchmark exposure can
distort apparent performance; hallucination and truthfulness studies
show that surface fluency and factual reliability can separate .

The MaoField programme proposed here treats this measurement apparatus
as an object of study. A residual-metric audit asks whether a reported
residual-like signal belongs to the evaluated model, the metric, the
judge, the sampling design, the aggregation weights, or a coupling among
them.

## Candidate finite objects

A first MaoField residual audit can remain finite. Choose two axes, for
example $$Q=\{\text{query or task classes}\},\qquad
B=\{\text{rubric, judge, benchmark or context classes}\}.$$ Let $w(q,b)$
be the empirical or designed weight assigned to each cell, and let
$K(q,b)$ be a score, error rate, preference margin, refusal rate,
hallucination indicator, calibration gap or other scalar diagnostic. The
theorem then supplies a concrete audit question:

> Are the row and column nuisance effects being removed by a true
> additive projection, or by an order-dependent sequential procedure
> whose output can be non-zero even for a pure main effect?

This yields six future objects:

1.  **Weight-form audit:** test how close $w(q,b)$ is to $w_Q(q)w_B(b)$
    before interpreting residuals.

2.  **Order-defect audit:** compute $R_{Q\to B}K-R_{B\to Q}K$ as a
    procedural sensitivity diagnostic, not as a model capability metric.

3.  **Projection audit:** compare sequential stripping outputs against
    the true projection residual $(I-P_{N_{\rm add}})K$.

4.  **Judge-axis audit:** treat human judge, model judge, rubric and
    prompt framing as separate axes rather than neutral measurement
    devices.

5.  **Contamination-axis audit:** separate benchmark exposure,
    paraphrase exposure and fresh-exam conditions as weighting or
    conditioning axes.

6.  **Mechanism-link audit:** where white-box access exists, compare
    black-box residual artefacts with mechanistic traces, without
    assuming that agreement or disagreement by itself proves mechanism.

## Mathematical directions

The present theorem is two-axis and exact. It suggests, but does not
prove, several mathematical extensions:

1.  **Near-product perturbation bounds:** bound $\|D_w\|$ in terms of a
    dependence measure such as $\|w-w_Q\otimes w_B\|$ under finite
    positivity assumptions.

2.  **Multi-axis charts:** replace $Q\times B$ by
    $X_1\times\cdots\times X_m$ and study when nuisance-removal paths
    are invariant.

3.  **Residual stability classes:** identify signals $K$ for which
    sequential residuals are stable even under non-product weights.

4.  **Audit geometry:** treat changes in benchmark design, judge model
    or weighting scheme as chart changes and measure residual
    instability across charts.

5.  **Certificate libraries:** build exact rational counterexamples that
    make metric artifacts reproducible without relying on floating-point
    evidence.

These are future mathematical problems. The present note proves only the
two-axis theorem above.

## Bottom-level LLM questions

The programme also identifies foundational questions about LLM
evaluation and black-box metrics:

1.  When a score changes, is the change caused by model behaviour,
    prompt distribution, judge bias, rubric drift, benchmark
    contamination, sampling variance or aggregation weight?

2.  When a residual-like score is non-zero, is it a true residual
    relative to a declared nuisance model, or an artifact of a
    procedural stripping order?

3.  When an LLM judge agrees with human preference, which nuisance axes
    have been controlled, and which biases remain latent?

4.  When a hallucination detector based on self-consistency fires, does
    it detect falsehood, uncertainty, prompt instability, or semantic
    dispersion?

5.  When a benchmark saturates, does the scalar score still measure
    capability, or mainly benchmark design and contamination state?

The MaoField direction is to make these questions finite, auditable and
algebraically explicit before adding empirical scale.

# Related work and positioning

This note is adjacent to, but not a replacement for, several established
literatures. Dependent-input functional decompositions and sensitivity
analysis already address the difficulty of attributing output variance
when inputs are statistically dependent . Classical projection theory
studies products and commutators of projections in far greater
generality . Language-model evaluation research has developed broad
benchmark suites, model-based evaluation, trustworthiness audits,
hallucination detection and contamination analysis .

The contribution here is narrower: a finite weighted two-way
projection-order artifact with an exact rational certificate, plus a
proposed programme for applying the same audit discipline to residual
metrics in language-model evaluation. The duplicate-risk ceiling remains
medium because neighbouring literatures already contain rich treatments
of dependent inputs, projection products and evaluation validity. The
manuscript should therefore remain narrow.

# Limitations

The limitations are structural.

1.  The theorem is finite-dimensional and two-axis. It does not cover
    arbitrary multi-axis evaluation pipelines.

2.  The theorem concerns orthogonal projections in $L^2(w)$, not causal
    effects, semantic truth, mechanistic circuits or human preference.

3.  The exact witness is a certificate of possibility, not evidence
    about an actual language model.

4.  The MaoField programme is a proposal for future residual-metric
    audits. No empirical MaoField claim is made.

5.  Floating-point harnesses, if supplied, are regression support only.
    They are not proof authority.

# Methods and reproducibility

All mathematical statements in the theorem are proved analytically in
the text. The $2\times2$ witness is rational and can be checked by exact
arithmetic. A minimal independent check requires only the weight matrix,
the witness vector and the projection definitions in $L^2(w)$. The
squared norm computation is displayed explicitly. Any accompanying
software should be treated as a consistency harness, not as the source
of mathematical authority.

# Acknowledgements

Author and PI acknowledgements should be added only by the human PI.

<div class="thebibliography">

99 BIG-bench authors. Beyond the Imitation Game: Quantifying and
extrapolating the capabilities of language models. arXiv:2206.04615
(2022).

Liang, P. et al. Holistic Evaluation of Language Models.
arXiv:2211.09110 (2022).

Lin, S., Hilton, J. and Evans, O. TruthfulQA: Measuring How Models Mimic
Human Falsehoods. arXiv:2109.07958 (2021).

Manakul, P., Liusie, A. and Gales, M. J. F. SelfCheckGPT: Zero-Resource
Black-Box Hallucination Detection for Generative Large Language Models.
arXiv:2303.08896 (2023).

Liu, Y. et al. G-Eval: NLG Evaluation using GPT-4 with Better Human
Alignment. arXiv:2303.16634 (2023).

Zheng, L. et al. Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena.
arXiv:2306.05685 (2023).

Wang, B. et al. DecodingTrust: A Comprehensive Assessment of
Trustworthiness in GPT Models. arXiv:2306.11698 (2023).

Chang, Y. et al. A Survey on Evaluation of Large Language Models.
arXiv:2307.03109 (2023).

Xu, C., Guan, S., Greene, D. and Kechadi, M.-T. Benchmark Data
Contamination of Large Language Models: A Survey. arXiv:2406.04244
(2024).

Yang, S., Chiang, W.-L., Zheng, L., Gonzalez, J. E. and Stoica, I.
Rethinking Benchmark and Contamination for Language Models with
Rephrased Samples. arXiv:2311.04850 (2023).

Chastaing, G., Gamboa, F. and Prieur, C. Generalized Hoeffding-Sobol
Decomposition for Dependent Variables - Application to Sensitivity
Analysis. arXiv:1112.1788 (2011).

Chastaing, G., Prieur, C. and Gamboa, F. Generalized Sobol sensitivity
indices for dependent variables: numerical methods. arXiv:1303.4372
(2013).

Owen, A. B. and Prieur, C. On Shapley Value for Measuring Importance of
Dependent Inputs. SIAM/ASA Journal on Uncertainty Quantification 5,
986–1002 (2017).

Iooss, B. and Prieur, C. Shapley effects for sensitivity analysis with
correlated inputs: comparisons with Sobol’ indices, numerical estimation
and applications. International Journal for Uncertainty Quantification
9, 493–514 (2019).

Corach, G. and Maestripieri, A. Products of orthogonal projections and
polar decompositions. arXiv:1011.5237 (2010).

</div>
