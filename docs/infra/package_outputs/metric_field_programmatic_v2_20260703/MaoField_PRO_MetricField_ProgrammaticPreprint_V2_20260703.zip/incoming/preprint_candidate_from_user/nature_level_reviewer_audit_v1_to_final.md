# Nature-level reviewer audit: V1 -> final candidate

## Verdict on V1

Recommendation: major revision before any preprint-style use.

V1 had a valid mathematical core, but it was not yet a polished preprint. It mixed package-governance language with manuscript text, lacked an external research frame, did not give MaoField enough programmatic structure, and did not sharply separate theorem, interpretation, and future empirical programme. The revised candidate repairs those issues while preserving the exact finite theorem and the 2 x 2 rational certificate.

## Major reviewer concerns and revisions

| Reviewer concern | Nature-level revision |
|---|---|
| V1 read like an internal audit report rather than a preprint. | Removed governance scaffolding from the manuscript body and rewrote as a self-contained article. |
| Mathematical claims needed to be compressed into a theorem-proof structure. | Consolidated product-weight orthogonality, order independence, and existential witness into one theorem with a full proof. |
| The true residual vs sequential artifact distinction needed stronger emphasis. | Added a dedicated section: `Why this matters for residual metrics`. |
| MaoField direction was underdeveloped. | Added a programmatic section on residual audits of complex black-box metrics, including candidate finite objects, mathematical directions, and bottom-level LLM questions. |
| Literature positioning was too internal. | Added references to LLM evaluation, benchmark suites, LLM-as-judge, hallucination, trustworthiness, contamination, dependent-input decompositions, Shapley effects, and projection products. |
| Risk of overclaiming MaoField empirical status. | Stated repeatedly that MaoField material is programmatic and no empirical MaoField result is reported. |
| Harness and exact witness could be confused. | The final manuscript states that the witness is exact rational arithmetic and that software, if present, is only consistency support. |

## Residual risks

1. Duplicate risk remains medium because dependent-input decompositions, Shapley/Sobol analysis, and two-projection theory are substantial existing literatures.
2. The MaoField programme is only a proposed research direction; empirical validation still requires a separate package.
3. The author list, PI authorization, Zenodo linkage, and public posting route remain unset.
4. If submitted to a high-level venue, the contribution must be framed as a concise mathematical caution plus programme, not as a complete theory of LLM evaluation.

## Final candidate status

The revised file is suitable as a polished local preprint candidate for PI review. It is not peer-reviewed, not journal-accepted, and not automatically authorized for public posting.
