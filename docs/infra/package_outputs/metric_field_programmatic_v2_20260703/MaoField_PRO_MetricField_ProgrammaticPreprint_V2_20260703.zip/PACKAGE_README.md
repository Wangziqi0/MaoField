# MaoField Metric-Field Programmatic Preprint V2 Package

This is a zero-context package for GPT-5.5 Pro. It asks for a rigorous
programmatic V2 preprint draft candidate under lock, using the finite
order-defect theorem as a mathematical wedge for the MaoField residual metric
audit programme.

This package is not public-release, posting, submission, paper-ready, or
preprint-ready authorization.

Start with:

- `prompt/GPT55_PRO_MAOFIELD_METRIC_FIELD_PROGRAMMATIC_PREPRINT_V2_PROMPT_20260703.md`
- `from_repo/STATE.md`
- `from_repo/docs/infra/gpt_deep_research/ORDER_DEFECT_METRIC_FIELD_PROGRAMME_REFRAME_REPORT21_ADOPTION_NOTE_20260703.md`
- `incoming/report21_metric_field_programme_reframe_pasted_text.md`
- `incoming/preprint_candidate_from_user/maofield_order_defect_final_candidate.tex`
- `from_repo/docs/infra/recovery/ORDER_DEFECT_D703_FORMAL_PREPRINT_DRAFT_GATE_TASKBOOK_20260703.md`

Hard boundary: Mode B MaoField empirical status remains `insufficient_artifact`.
