# D708 Internal V0 Promotion Gate Package

Use `START_HERE_MAIN_PROMPT_20260708_1001_internal_v0_gate.md` as the zero-context prompt.

This package is for strict internal review of `docs/infra/debranded_residual_transport/FORMAL_NOTE_D707_CHART_PATH_CYCLE_DEFECT_V0_20260707.md` only.

It asks GPT-5.5 Pro to choose exactly one verdict:

```text
ACCEPT_INTERNAL_V0_AS_LOCAL_NOTE_ONLY
PATCH_INTERNAL_V0_THEN_RECHECK
REJECT_OR_STOP_PARK
REQUEST_NODE36_FILES
```

It does not authorize a public/paper/NMI-ready claim, a MaoField empirical-positive claim, a broad theory claim, or proof by RAG/JSON/harness/package.

Package accounting: `MANIFEST_D708_INTERNAL_V0_PROMOTION_GATE_20260708.txt` lists payload files. The zip also contains this README and an internal SHA256SUMS file for integrity checking.
