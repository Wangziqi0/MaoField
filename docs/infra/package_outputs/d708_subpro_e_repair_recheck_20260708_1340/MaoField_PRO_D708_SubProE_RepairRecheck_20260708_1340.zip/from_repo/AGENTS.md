# MaoField on Node 36

This is the canonical MaoField project under `/media/amd/raid1/canonical/projects/MaoField`.

## First Read

Before work:

```bash
date '+%F %T %Z'
git status --short
sed -n '1,160p' STATE.md
sed -n '1,160p' CLAUDE.md
```

If `STATE.md` is absent or unclear, report that before using stale status.

## Project Authority

- This project inherits `/media/amd/raid1/canonical/AGENTS.md`.
- `CLAUDE.md` remains a method-source document; do not delete or rewrite it during Codex migration.
- `STATE.md` is the only place for live phase, date, submission status, and current task truth.
- `MD_CATALOG.md` is the navigation and RAG coverage map when present.

## Research Method

- Negative results and ablations must be represented honestly.
- Experiment numbers require JSON/log/source paths.
- Probability estimates require explicit assumptions and should be downshifted when validation is missing.
- Claims must pass a second-channel review before promotion.
- Distinguish code behavior from paper interpretation; if they disagree, default to code/log evidence until audited.

## Node Routing

- Use 36 for RAG, canonical file edits, CPU-heavy symbolic checks, review, and git push.
- Use 22 for authorized ROCm/GPU runs and return packages.
- Use 19/142 as thin terminals only unless the task is explicitly outside the research storage discipline.

## Output Requirements

Every substantial result should include:
- command or source path;
- git commit and dirty state;
- evidence files;
- missing evidence;
- claim category: observed, derived, claimed, or blocked;
- whether promotion to canonical is allowed.

## Do Not Do

- Do not revive locked-out NOT-claims.
- Do not write live schedule or status into `AGENTS.md` or `CLAUDE.md`.
- Do not import worker scratch into canonical without classification.
- Do not push until `git status --short` and scope are reviewed.

