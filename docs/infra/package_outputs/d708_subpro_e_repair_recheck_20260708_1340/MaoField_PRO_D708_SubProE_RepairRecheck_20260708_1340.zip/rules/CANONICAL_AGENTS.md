# Canonical Research Constitution for Codex

This directory is the root canonical authority for the three-machine research system.

## Priority Chain

1. User instruction in the current session.
2. This `AGENTS.md`.
3. Project-level `AGENTS.md`.
4. Existing `CLAUDE.md` files as legacy research-method authority.
5. `STATE.md`, handoffs, logs, and primary-source evidence for volatile facts.
6. Model reasoning.

When rules conflict, stop and surface the conflict with exact file paths.

## Non-Negotiable Rules

- On node36, also apply the per-request correction hook in
  `/home/amd/.codex/AGENTS.md`: verify time, read project `STATE.md`, run
  execution in `/home/amd/codex-node36/tmp/<task>/`, use node22 for one-shot
  embedding/vector builds when available, keep git push authority on node36,
  and gate claims on primary evidence rather than RAG or smoke artifacts.
- Verify current date/time before any claim about today, deadlines, freshness, or status.
- Volatile state belongs in `STATE.md`, not in durable rule files.
- Canonical state is `/media/amd/raid1/canonical`, not arbitrary scratch on `/home` or worker nodes.
- Node 36 is the only default git push node for research repositories.
- Node 22 and thin clients may produce artifacts; 36 decides promotion only after evidence review.
- RAG is for semantic location and summary, not a substitute for primary evidence.
- Do not use acceptance-probability language without assumptions and evidence.
- Do not say "ready" unless all stated gates are binary checked.

## RAG Discipline

Use canonical RAG to find candidate documents, then verify with file reads or primary sources.

MaoField query pattern:

```bash
HF_HUB_OFFLINE=1 /home/amd/venv/bin/python /media/amd/raid1/rag/kb_search.py "query" --top-k 8 --project MaoField
```

Return paths, snippets, and uncertainty. Do not turn RAG summaries into claims without source verification.

## Storage Discipline

Before writing into canonical, identify one category:
- `core`: source, paper text, locked methodology, curated knowledge.
- `wip`: valuable in-progress work that needs redundancy.
- `artifact`: logs, metrics, checkpoints, result packages.
- `temp`: disposable local scratch, should not enter canonical.

If a file is irreproducible, ensure it has a canonical or backed-up copy before ending the task.

## Git Discipline

- Run `git status --short` before edits.
- Do not commit unrelated generated files.
- Do not push changes from worker nodes.
- Do not rewrite history without explicit user instruction.
- Treat untracked files as user work until proven otherwise.

## Claim Gate Vocabulary

- `observed`: directly measured in logs, data, or source text.
- `derived`: computed from observed evidence by a stated script/formula.
- `claimed`: interpretation requiring methodology and primary-source support.
- `blocked`: missing evidence or authority.

Keep these categories separate in reports.
