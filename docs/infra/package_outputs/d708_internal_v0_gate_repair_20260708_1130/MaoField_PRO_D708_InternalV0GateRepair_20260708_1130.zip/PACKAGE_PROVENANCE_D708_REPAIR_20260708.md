# D708 Repair Package Provenance

This package repairs the package/provenance gaps identified by Main Pro report39.

Report39 verdict:

```text
REQUEST_NODE36_FILES
```

The repair package includes the previously omitted loop status files:

```text
docs/infra/recovery/d707_split_loop_outputs/loop0/LOOP_STATUS_LOOP0_20260707.md
docs/infra/recovery/d707_split_loop_outputs/loop3/LOOP_STATUS_LOOP3_20260707.md
docs/infra/recovery/d707_split_loop_outputs/loop4/LOOP_STATUS_LOOP4_20260707.md
```

It also includes the D708 package/delivery/RAG records and package path mappings
for rule files:

```text
rules/PROJECT_AGENTS.md      <- project AGENTS.md snapshot
rules/CANONICAL_AGENTS.md    <- /media/amd/raid1/canonical/AGENTS.md snapshot
rules/CLAUDE.md              <- CLAUDE.md snapshot
```

Self-reference note: the zip's final SHA256 is intentionally not embedded in
`STATE.md`. A zip cannot contain a file that already knows the final hash of the
zip containing it. Use the external `SHA256SUMS_...txt`, this package's internal
payload checksum file, and the node19 delivery readback for zip integrity.

This package is still internal gate review only. It does not authorize a paper,
public release, NMI readiness, empirical positive claim, broad theory claim, or
proof by package/RAG/JSON/harness/model output.
